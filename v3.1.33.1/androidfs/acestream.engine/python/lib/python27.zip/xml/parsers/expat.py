"""Interface to the Expat non-validating XML parser."""
__version__ = '$Revision$'

from pyexpat import *
